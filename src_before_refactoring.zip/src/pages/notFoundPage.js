import React from 'react';

const NotFoundPage = () => {
    return ( 
        <div className="container">
            <div className="row"><p>Not Found Page</p></div>
        </div> 
        );
}
export default NotFoundPage;