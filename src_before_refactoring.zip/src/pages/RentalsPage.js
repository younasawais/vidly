import React from 'react';

const RentalsPage = () => {
    return ( 
        <div className="container">
            <div className="row"><p>Rentals Page</p></div>
        </div> 
        );
}
 
export default RentalsPage;