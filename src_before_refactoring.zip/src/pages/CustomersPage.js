import React from 'react';

const CustomersPage = () => {
    return (
        <div className="container">
            <div className="row"> 
                <p>Customers Page</p>
            </div>
        </div> 
        );
}
 
export default CustomersPage;